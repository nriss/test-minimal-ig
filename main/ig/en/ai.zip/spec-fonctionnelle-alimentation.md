# Alimentation - ANS IG Example v0.1.0

## Alimentation

 
There is no translation page available for the current page, so it has been rendered in the default language 

### Alimentation

Description fonctionnelle de l'alimentation

